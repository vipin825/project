Doctor Patient REST Service (Doctor, Patient etc) to manage all the basic CRUD operations.
