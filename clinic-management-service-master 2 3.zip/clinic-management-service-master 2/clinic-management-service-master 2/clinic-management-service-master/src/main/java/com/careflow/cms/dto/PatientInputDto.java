package com.careflow.cms.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatientInputDto {

    @NotBlank(message = "First Name is required")
    @Size(max = 50, message = "First Name cannot have more than 50 characters")
    private String firstName;

    @NotBlank(message = "Last Name is required")
    @Size(max = 50, message = "Last Name cannot have more than 50 characters")
    private String lastName;

    @Past(message = "Date of Birth must be in the past")
    private LocalDate dateOfBirth;
    @NotNull(message = "Gender is required")
    @Pattern(regexp = "^[MF]$", message = "Gender must be 'M' or 'F' ")
    private String gender;

    @Pattern(regexp = "^[0-9]{10,18}$", message = "Invalid Phone Number")
    @Size(max = 20, message = "Phone Number cannot have more than 20 characters")
    private String phoneNumber;

    @Email(message = "Email should be valid")
    @Size(max = 100, message = "Email cannot have more than 100 characters")
    private String email;

    private Long doctorId;
}
