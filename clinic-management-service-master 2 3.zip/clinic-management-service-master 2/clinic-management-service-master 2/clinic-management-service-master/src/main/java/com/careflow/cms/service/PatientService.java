package com.careflow.cms.service;

import com.careflow.cms.dto.DoctorSummaryDto;
import com.careflow.cms.dto.PatientDto;
import com.careflow.cms.dto.PatientInputDto;
import com.careflow.cms.exception.DoctorCapacityExceededException;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.repository.PatientRepository;
import jakarta.persistence.EntityManager;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PatientService {

    private static final Logger log = LoggerFactory.getLogger(PatientService.class);
    private static final int MAX_PATIENTS_PER_DOCTOR = 4;
    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private EntityManager entityManager;

    @Transactional
    public PatientDto create(PatientInputDto patientInputDto) {
        log.info("Creating Patient : {} {}", patientInputDto.getFirstName(), patientInputDto.getLastName());
        Patient patient = mapper.map(patientInputDto, Patient.class);

        patient.setPatientId(null); // Force to null to avoid update
        if (patientInputDto.getDoctorId() != null) {
            Doctor doctor = getDoctorWithCapacityCheck(patientInputDto.getDoctorId());

            patient.setDoctor(doctor);
        } else {
            patient.setDoctor(null);
        }
        Patient saved = patientRepository.save(patient);
        System.out.println(saved);
        return mapToDto(saved);
    }

    public List<PatientDto> getAll(){
        log.info("Get All Patients");
        List<Patient> patients = patientRepository.findAll();
        return patients.stream()
                .map(this::mapToDto).toList();
    }

    @Transactional
    public PatientDto update(Long id, PatientInputDto patientInputDto) {
        log.info("Update Patient {}", id);
        Patient existing = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));

        existing.setFirstName(patientInputDto.getFirstName());
        existing.setLastName(patientInputDto.getLastName());
        existing.setDateOfBirth(patientInputDto.getDateOfBirth());
        existing.setGender(patientInputDto.getGender().charAt(0));
        existing.setPhoneNumber(patientInputDto.getPhoneNumber());
        existing.setEmail(patientInputDto.getEmail());

        //mapper.map(patientInputDto, existing);

        if (patientInputDto.getDoctorId() != null) {
            Doctor doctor = getDoctorWithCapacityCheck(patientInputDto.getDoctorId(), existing.getPatientId());
            existing.setDoctor(doctor);
        }else{
            existing.setDoctor(null);
        }
        return mapToDto(patientRepository.save(existing));
    }

    @Transactional
    public void delete(Long id) {
        log.info("Delete Patient with Id {}", id);
        if (!patientRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot find Patient with id : " + id);
        }
        patientRepository.deleteById(id);
    }

    public PatientDto getById(Long id) {
        log.info("Get Patient by Id {}", id);
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));
        return mapToDto(patient);
    }

    private Doctor getDoctorWithCapacityCheck(Long doctorId, Long excludedPatientId) {
        log.info("Get Doctor Capacity for Doctor with Id {}", doctorId);
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + doctorId));

        long patientCount = patientRepository.countPatientsByDoctorIdExcluding(doctorId, excludedPatientId);
        entityManager.detach(doctor);

        if (patientCount >= MAX_PATIENTS_PER_DOCTOR) {
            throw new DoctorCapacityExceededException("Doctor with Id " + doctorId + " already has the maximum allowed number of patients.");
        }

        return doctor;
    }

    private Doctor getDoctorWithCapacityCheck(Long doctorId) {
        return getDoctorWithCapacityCheck(doctorId,null);
    }

    @Transactional
    public PatientDto assignDoctor(Long patientId, Long doctorId){
        log.info("Assign Doctor Id {} to Patient Id {}", doctorId, patientId);
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + patientId));

        Doctor doctor = getDoctorWithCapacityCheck(doctorId,patientId);
        patient.setDoctor(doctor);

        return mapToDto(patientRepository.save(patient));
    }

    @Transactional
    public PatientDto removeDoctor(Long patientId){
        log.info("Remove Doctor from Patient Id {}", patientId);
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + patientId));

        patient.setDoctor(null);

        return mapToDto(patientRepository.save(patient));
    }

    private PatientDto mapToDto(Patient patient) {
        PatientDto patientDto = mapper.map(patient, PatientDto.class);
        if (patient.getDoctor() != null) {
            DoctorSummaryDto doctorSummaryDto = mapper.map(patient.getDoctor(), DoctorSummaryDto.class);
            patientDto.setDoctorSummaryDto(doctorSummaryDto);
        } else {
            patientDto.setDoctorSummaryDto(null);
        }
        return patientDto;
    }


}
