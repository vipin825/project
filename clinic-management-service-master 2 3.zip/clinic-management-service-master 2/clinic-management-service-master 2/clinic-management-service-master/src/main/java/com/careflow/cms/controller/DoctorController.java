package com.careflow.cms.controller;

import com.careflow.cms.dto.DoctorDto;
import com.careflow.cms.dto.DoctorInputDto;
import com.careflow.cms.service.DoctorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cms/v1/doctors")
@Tag(name = "Doctors API", description = "Doctors API for CRUD Operation")
public class DoctorController {

    private static final Logger log = LoggerFactory.getLogger(DoctorController.class);

    @Autowired
    private DoctorService doctorService;

    @PostMapping
    @Operation(summary = "Create a New Doctor")
    public ResponseEntity create(@Valid @RequestBody DoctorInputDto doctorInputDTO) {
        log.info("Received request: POST /api/doctors with data: {}", doctorInputDTO);
        DoctorDto created = doctorService.create(doctorInputDTO);
        log.info("Created doctor with id {}", created.getDoctorId());
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Display a List of Doctors")
    public ResponseEntity<List<DoctorDto>> getAll() {
        log.info("Received request: GET /api/doctors");
        List<DoctorDto> doctors = doctorService.getAll();
        log.info("Returning {} doctors", doctors.size());
        return ResponseEntity.ok(doctors);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an Existing Doctor")
    public ResponseEntity<DoctorDto> update(@PathVariable Long id, @Valid @RequestBody DoctorInputDto doctorInputDTO) {
        log.info("Received request: PUT /api/doctors/{} with data: {}", id, doctorInputDTO);
        DoctorDto doctorDto = doctorService.update(id, doctorInputDTO);
        log.info("Updated doctor with id {}", id);
        return ResponseEntity.ok(doctorDto);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an Existing Doctor")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.info("Received request: DELETE /api/doctors/{}", id);
        doctorService.delete(id);
        log.info("Deleted doctor with id {}", id);
        return ResponseEntity.noContent().build();
    }

   @GetMapping("/{id}")
   @Operation(summary = "Find an Existing Doctor")
   public ResponseEntity<DoctorDto> getById(@PathVariable Long id) {
       log.info("Received request: GET /api/doctors/{}", id);
       DoctorDto doctor = doctorService.getById(id);
       log.info("Returning doctor with id {}", id);

       return ResponseEntity.ok(doctor);
    }
}
