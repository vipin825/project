package com.careflow.cms.integration;

import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.model.AppointmentStatus;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.repository.PatientRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestInstance(TestInstance.Lifecycle.PER_CLASS)

class AppointmentControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private PatientRepository patientRepository;

    private Long doctorId;
    private Long patientId;
    private Long appointmentId;

    @BeforeEach
    void setup() throws Exception {
        // Create doctor
        Doctor doctor = new Doctor();
        doctor.setFirstName("Integration");
        doctor.setLastName("Doctor");
        doctor = doctorRepository.save(doctor);
        doctorId = doctor.getDoctorId();

        // Create patient
        Patient patient = new Patient();
        patient.setFirstName("Integration");
        patient.setLastName("Patient");
        patient.setGender('m');
        patient = patientRepository.save(patient);
        patientId = patient.getPatientId();

        // Create appointment via controller
        AppointmentInputDto inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(doctorId);
        inputDto.setPatientId(patientId);
        inputDto.setAppointmentDate(LocalDate.now());
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        String response = mockMvc.perform(post("/api/cms/v1/appointments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        JsonNode jsonNode = objectMapper.readTree(response);
        appointmentId = jsonNode.get("appointmentId").asLong();
    }

    @Test
    void testCreateAppointment() throws Exception {
        AppointmentInputDto inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(doctorId);
        inputDto.setPatientId(patientId);
        inputDto.setAppointmentDate(LocalDate.now().plusDays(1));
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        mockMvc.perform(post("/api/cms/v1/appointments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.appointmentId").exists());
    }

    @Test
    void testGetAllAppointments() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    void testGetAppointmentById() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/" + appointmentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
    }

    @Test
    void testUpdateAppointment() throws Exception {
        AppointmentInputDto inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(doctorId);
        inputDto.setPatientId(patientId);
        inputDto.setAppointmentDate(LocalDate.now().plusDays(2));
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        mockMvc.perform(put("/api/cms/v1/appointments/" + appointmentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
    }

    @Test
    void testDeleteAppointment() throws Exception {
        mockMvc.perform(delete("/api/cms/v1/appointments/" + appointmentId))
                .andExpect(status().isNoContent());
    }

    @Test
    void testGetAppointmentsForToday() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/today"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDoctor() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDateAndStatus() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/date/")
                        .param("date", LocalDate.now().toString())
                        .param("status", AppointmentStatus.SCHEDULED.name()))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDoctorAndDate() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId + "/date")
                        .param("date", LocalDate.now().toString()))
                .andExpect(status().isOk());
    }

    @Test
    void testGetPatientsByAppointmentDateAndStatus() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/patients")
                        .param("date", LocalDate.now().toString())
                        .param("status", AppointmentStatus.SCHEDULED.name()))
                .andExpect(status().isOk());
    }
}
