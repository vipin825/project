package com.careflow.cms.test;

import com.careflow.cms.dto.DoctorDto;
import com.careflow.cms.dto.DoctorInputDto;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.service.DoctorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DoctorServiceTest {

    @InjectMocks
    private DoctorService doctorService;

    @Mock
    private DoctorRepository doctorRepository;

    @Mock
    private ModelMapper modelMapper;

    @Test
    void testCreateDoctor() {
        DoctorInputDto inputDto = new DoctorInputDto();
        Doctor doctor = new Doctor();
        Doctor savedDoctor = new Doctor();
        DoctorDto doctorDto = new DoctorDto();

        when(modelMapper.map(inputDto, Doctor.class)).thenReturn(doctor);
        when(doctorRepository.save(doctor)).thenReturn(savedDoctor);
        when(modelMapper.map(savedDoctor, DoctorDto.class)).thenReturn(doctorDto);

        DoctorDto result = doctorService.create(inputDto);

        assertNotNull(result);
        verify(doctorRepository).save(doctor);
    }

    @Test
    void testGetAllDoctors() {
        Doctor doctor = new Doctor();
        DoctorDto doctorDto = new DoctorDto();

        when(doctorRepository.findAll()).thenReturn(List.of(doctor));
        when(modelMapper.map(doctor, DoctorDto.class)).thenReturn(doctorDto);

        List<DoctorDto> result = doctorService.getAll();

        assertEquals(1, result.size());
    }

@Test
void testUpdateDoctor() {
    Long id = 1L;
    DoctorInputDto inputDto = new DoctorInputDto();
    Doctor existing = new Doctor();
    Doctor updated = new Doctor();
    DoctorDto doctorDto = new DoctorDto();

    when(doctorRepository.findById(id)).thenReturn(Optional.of(existing));

    // Add this line to fix the stubbing mismatch
    doNothing().when(modelMapper).map(inputDto, existing);

    when(doctorRepository.save(existing)).thenReturn(updated);
    when(modelMapper.map(updated, DoctorDto.class)).thenReturn(doctorDto);

    DoctorDto result = doctorService.update(id, inputDto);

    assertNotNull(result);
    verify(doctorRepository).save(existing);
}


    @Test
    void testDeleteDoctor() {
        Long id = 1L;
        when(doctorRepository.existsById(id)).thenReturn(true);

        doctorService.delete(id);

        verify(doctorRepository).deleteById(id);
    }

    @Test
    void testGetDoctorById() {
        Long id = 1L;
        Doctor doctor = new Doctor();
        DoctorDto doctorDto = new DoctorDto();

        when(doctorRepository.findById(id)).thenReturn(Optional.of(doctor));
        when(modelMapper.map(doctor, DoctorDto.class)).thenReturn(doctorDto);

        DoctorDto result = doctorService.getById(id);

        assertNotNull(result);
    }
}
