package com.careflow.cms.test;

import com.careflow.cms.dto.AppointmentDto;
import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.dto.DoctorSummaryDto;
import com.careflow.cms.dto.PatientSummaryDto;
import com.careflow.cms.exception.ConflictException;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.*;
import com.careflow.cms.repository.AppointmentRepository;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.repository.PatientRepository;
import com.careflow.cms.service.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.modelmapper.ModelMapper;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class AppointmentServiceTest {

    @InjectMocks
    private AppointmentService appointmentService;

    @Mock
    private AppointmentRepository appointmentRepository;

    @Mock
    private DoctorRepository doctorRepository;

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private ModelMapper modelMapper;

    private AppointmentInputDto inputDto;
    private Doctor doctor;
    private Patient patient;
    private Appointment appointment;
    private AppointmentDto appointmentDto;

    @BeforeEach
    void setUp() {
        inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(1L);
        inputDto.setPatientId(2L);
        inputDto.setAppointmentDate(LocalDate.now());
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        doctor = new Doctor();
        doctor.setDoctorId(1L);

        patient = new Patient();
        patient.setPatientId(2L);

        appointment = new Appointment();
        appointment.setAppointmentId(10L);
        appointment.setDoctor(doctor);
        appointment.setPatient(patient);
        appointment.setAppointmentDate(inputDto.getAppointmentDate());
        appointment.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        appointmentDto = new AppointmentDto();
        appointmentDto.setAppointmentId(10L);
    }

    @Test
    void testCreateAppointment_success() {
        when(patientRepository.findById(2L)).thenReturn(Optional.of(patient));
        when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
        when(appointmentRepository.findByPatientAndAppointmentDateAndAppointmentStatus(patient, inputDto.getAppointmentDate(), inputDto.getAppointmentStatus()))
                .thenReturn(Optional.empty());
        when(patientRepository.countPatientsByDoctorIdExcluding(1L, null)).thenReturn(0L);
        when(modelMapper.map(inputDto, Appointment.class)).thenReturn(appointment);
        when(appointmentRepository.save(any(Appointment.class))).thenReturn(appointment);
        when(modelMapper.map(appointment, AppointmentDto.class)).thenReturn(appointmentDto);
        when(modelMapper.map(doctor, DoctorSummaryDto.class)).thenReturn(new DoctorSummaryDto());
        when(modelMapper.map(patient, PatientSummaryDto.class)).thenReturn(new PatientSummaryDto());

        AppointmentDto result = appointmentService.create(inputDto);

        assertNotNull(result);
        assertEquals(10L, result.getAppointmentId());
        verify(appointmentRepository).save(any(Appointment.class));
    }

    @Test
    void testCreateAppointment_patientNotFound() {
        when(patientRepository.findById(2L)).thenReturn(Optional.empty());
        when(modelMapper.map(inputDto, Appointment.class)).thenReturn(new Appointment());

        assertThrows(ResourceNotFoundException.class, () -> appointmentService.create(inputDto));
    }

    @Test
    void testCreateAppointment_doctorNotFound() {
        when(patientRepository.findById(2L)).thenReturn(Optional.of(patient));
        when(doctorRepository.findById(1L)).thenReturn(Optional.empty());
        when(modelMapper.map(inputDto, Appointment.class)).thenReturn(new Appointment());
        assertThrows(ResourceNotFoundException.class, () -> appointmentService.create(inputDto));
    }

    @Test
    void testCreateAppointment_duplicateAppointment() {
        when(patientRepository.findById(2L)).thenReturn(Optional.of(patient));
        when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
        when(appointmentRepository.findByPatientAndAppointmentDateAndAppointmentStatus(patient, inputDto.getAppointmentDate(), inputDto.getAppointmentStatus()))
                .thenReturn(Optional.of(new Appointment()));
        when(modelMapper.map(inputDto, Appointment.class)).thenReturn(new Appointment());


        assertThrows(ConflictException.class, () -> appointmentService.create(inputDto));
    }

    @Test
    void testDeleteAppointment_success() {
        when(appointmentRepository.existsById(10L)).thenReturn(true);

        appointmentService.delete(10L);

        verify(appointmentRepository).deleteById(10L);
    }

    @Test
    void testDeleteAppointment_notFound() {
        when(appointmentRepository.existsById(10L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> appointmentService.delete(10L));
    }
}
