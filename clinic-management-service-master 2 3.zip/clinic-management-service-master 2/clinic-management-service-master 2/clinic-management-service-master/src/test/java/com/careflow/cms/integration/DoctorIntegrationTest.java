package com.careflow.cms.integration;

import com.careflow.cms.dto.DoctorInputDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class DoctorIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;
    @Test
    void testCreateDoctor() throws Exception {
        DoctorInputDto inputDto = new DoctorInputDto();
        inputDto.setFirstName("John");
        inputDto.setLastName("Doe");
        // Add other required fields if any

        mockMvc.perform(post("/api/cms/v1/doctors")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.doctorId").exists());
    }


    @Test
    void testGetAllDoctors() throws Exception {
        mockMvc.perform(get("/api/cms/v1/doctors"))
                .andExpect(status().isOk());
    }
}
