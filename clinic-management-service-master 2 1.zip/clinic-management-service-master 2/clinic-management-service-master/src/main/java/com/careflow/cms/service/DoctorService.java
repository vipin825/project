package com.careflow.cms.service;

import com.careflow.cms.dto.DoctorDto;
import com.careflow.cms.dto.DoctorInputDto;
import com.careflow.cms.dto.PatientSummaryDto;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.repository.DoctorRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DoctorService {

    private static final Logger log = LoggerFactory.getLogger(DoctorService.class);

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private ModelMapper mapper;

    @Transactional
    public DoctorDto create(DoctorInputDto doctorInputDto) {
        log.info("Creating Doctor : {} {}", doctorInputDto.getFirstName(), doctorInputDto.getLastName());
        Doctor doctor = mapper.map(doctorInputDto, Doctor.class);
        doctor.setDoctorId(null); // Force to null to avoid update
        Doctor saved = doctorRepository.save(doctor);
        return mapToDto(saved);
    }

    public List<DoctorDto> getAll() {
        log.info("Get All Doctors");
        List<Doctor> doctors = doctorRepository.findAll();
        return doctors.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public DoctorDto update(Long id, DoctorInputDto doctorInputDto) {
        log.info("Update Doctor {}", id);
        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + id));
        mapper.map(doctorInputDto, existing);

        return mapToDto(doctorRepository.save(existing));
    }

    @Transactional
    public void delete(Long id) {
        log.info("Delete Doctor {}", id);
        if (!doctorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot find Doctor with id : " + id);
        }
        doctorRepository.deleteById(id);
    }

    public DoctorDto getById(Long id) {
        log.info("Get Doctor by Id {}", id);
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + id));
        return mapToDto(doctor);
    }

    private DoctorDto mapToDto(Doctor doctor) {
        DoctorDto doctorDto = mapper.map(doctor, DoctorDto.class);
        List<PatientSummaryDto> patients = doctor.getPatients() != null ? doctor.getPatients().stream()
                .map(p -> mapper.map(p, PatientSummaryDto.class))
                .collect(Collectors.toList()) : null;
        doctorDto.setPatients(patients);
        return doctorDto;
    }
}
