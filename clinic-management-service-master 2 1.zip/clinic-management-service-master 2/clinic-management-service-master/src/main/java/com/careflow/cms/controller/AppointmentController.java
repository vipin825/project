package com.careflow.cms.controller;

import com.careflow.cms.dto.AppointmentDto;
import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.dto.PatientSummaryDto;
import com.careflow.cms.model.AppointmentStatus;
import com.careflow.cms.service.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/cms/v1/appointments")
@Tag(name = "Appointments API", description = "Appointments API for CRUD Operation")
public class AppointmentController {
    private static final Logger log = LoggerFactory.getLogger(AppointmentController.class);

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping
    @Operation(summary = "Create a New Appointment")
    public ResponseEntity<AppointmentDto> create(@Valid @RequestBody AppointmentInputDto appointmentInputDto) {
        log.info("Received request: POST /api/appointments");
        AppointmentDto appointmentDto = appointmentService.create(appointmentInputDto);
        log.info("Created appointment with id {}", appointmentDto.getAppointmentId());
        return new ResponseEntity<>(appointmentDto, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Display a List of Appointments")
    public ResponseEntity<List<AppointmentDto>> getAll() {
        log.info("Received request: GET /api/appointments");
        List<AppointmentDto> appointmentDtos = appointmentService.getAll();
        log.info("Returning {} appointments", appointmentDtos.size());
        return ResponseEntity.ok(appointmentDtos);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an Existing Appointment")
    public ResponseEntity<AppointmentDto> update(@PathVariable Long id, @Valid @RequestBody AppointmentInputDto appointmentInputDto) {
        log.info("Received request: PUT /api/appointments/{} with data: {}", id, appointmentInputDto);
        AppointmentDto appointmentDto = appointmentService.update(id, appointmentInputDto);
        log.info("Updated appointment with id {}", id);
        return ResponseEntity.ok(appointmentDto);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an Existing Appointment")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.info("Received request: DELETE /api/appointments/{}", id);
        appointmentService.delete(id);
        log.info("Deleted appointment with id {}", id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Find an Existing Appointment")
    public ResponseEntity<AppointmentDto> getById(@PathVariable Long id) {
        log.info("Received request: GET /api/appointments/{}", id);
        AppointmentDto appointmentDto = appointmentService.getById(id);
        log.info("Returning doctor with id {}", id);
        return ResponseEntity.ok(appointmentDto);
    }

    @GetMapping("/today")
    public ResponseEntity<List<AppointmentDto>> getAppointmentsForToday() {
        log.info("Received request: GET /api/appointments/today");
        List<AppointmentDto> appointmentDtos = appointmentService.getAppointmentsForToday();
        log.info("Returning {} appointments for Today", appointmentDtos.size());
        return ResponseEntity.ok(appointmentDtos);
    }

    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<AppointmentDto>> getAppointmentsByDoctor(@PathVariable Long doctorId) {
        log.info("Received request: GET /api/appointments/doctor/{}", doctorId);
        List<AppointmentDto> appointmentDtos = appointmentService.getAppointmentsByDoctor(doctorId);
        log.info("Returning {} appointments by Doctor", appointmentDtos.size());
        return ResponseEntity.ok(appointmentDtos);
    }

    @GetMapping("/date/")
    public ResponseEntity<List<AppointmentDto>> getAppointmentsByDateAndStatus(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam AppointmentStatus status) {
        log.info("Received request: GET /api/appointments?date={}&status={}", date, status);
        List<AppointmentDto> appointmentDtos = appointmentService.getAppointmentsByDateAndStatus(date, status);
        log.info("Returning {} appointments by Date and Status", appointmentDtos.size());
        return ResponseEntity.ok(appointmentDtos);
    }

    @GetMapping("/doctor/{doctorId}/date")
    public ResponseEntity<List<AppointmentDto>> getAppointmentsByDoctorAndDate(
            @PathVariable Long doctorId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        log.info("Received request: GET /api/appointments/doctor/{}/date?date={}", doctorId, date);
        List<AppointmentDto> appointmentDtos = appointmentService.getAppointmentsByDoctorAndDate(doctorId, date);
        log.info("Returning {} appointments by Doctor and Date", appointmentDtos.size());
        return ResponseEntity.ok(appointmentDtos);
    }

    @GetMapping("/patients")
    public ResponseEntity<List<PatientSummaryDto>> getPatientsByAppointmentDateAndStatus(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam AppointmentStatus status) {
        log.info("Received request: GET /api/appointments/patients?date={}&status={}", date, status);
        List<PatientSummaryDto> patientSummaryDtos = appointmentService.getPatientsByAppointmentDateAndStatus(date, status);
        log.info("Returning {} appointments by Patients and Appointment Date and Status", patientSummaryDtos.size());
        return ResponseEntity.ok(patientSummaryDtos);
    }
}
