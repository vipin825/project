package com.careflow.cms.config;
import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.model.Appointment;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();

        // Ignore ambiguity globally
        mapper.getConfiguration().setAmbiguityIgnored(true);

        // Skip mapping appointmentId from AppointmentInputDto to Appointment
        TypeMap<AppointmentInputDto, Appointment> typeMap = mapper.createTypeMap(AppointmentInputDto.class, Appointment.class);
        typeMap.addMappings(m -> m.skip(Appointment::setAppointmentId));

        return mapper;
    }
}

