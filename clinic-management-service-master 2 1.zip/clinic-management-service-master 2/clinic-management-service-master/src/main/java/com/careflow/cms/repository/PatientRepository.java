package com.careflow.cms.repository;

import com.careflow.cms.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PatientRepository extends JpaRepository<Patient,Long> {

    @Query("SELECT COUNT(p) FROM Patient p "
    + "WHERE p.doctor.doctorId = :doctorId "
    + "AND (:excludePatientId IS NULL OR p.patientId <> :excludePatientId)")
    long countPatientsByDoctorIdExcluding(@Param("doctorId") Long doctorId,
                                          @Param("excludePatientId") Long excludePatientId);
}
