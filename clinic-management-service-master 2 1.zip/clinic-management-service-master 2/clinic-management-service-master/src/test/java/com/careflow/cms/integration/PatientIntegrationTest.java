package com.careflow.cms.integration;

import com.careflow.cms.dto.PatientInputDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PatientIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testCreatePatient() throws Exception {
        PatientInputDto inputDto = new PatientInputDto();
        inputDto.setFirstName("Alice");
        inputDto.setLastName("Smith");
        inputDto.setDateOfBirth(LocalDate.of(1990, 1, 1));
        inputDto.setGender("F");
        inputDto.setPhoneNumber("9876543210");
        inputDto.setEmail("alice.smith@example.com");

        mockMvc.perform(post("/api/cms/v1/patients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.patientId").exists());
    }

    @Test
    void testGetAllPatients() throws Exception {
        mockMvc.perform(get("/api/cms/v1/patients"))
                .andExpect(status().isOk());
    }
}
