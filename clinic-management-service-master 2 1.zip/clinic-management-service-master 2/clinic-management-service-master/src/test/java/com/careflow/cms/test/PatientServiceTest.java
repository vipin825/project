package com.careflow.cms.test;

import com.careflow.cms.dto.*;

import com.careflow.cms.exception.*;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import com.careflow.cms.repository.*;
import com.careflow.cms.service.PatientService;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.modelmapper.ModelMapper;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class PatientServiceTest {

    @InjectMocks
    private PatientService patientService;

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private DoctorRepository doctorRepository;

    @Mock
    private ModelMapper modelMapper;

    @Mock
    private EntityManager entityManager;

//    @Test
//    void testCreatePatientWithDoctor() {
//        PatientInputDto inputDto = new PatientInputDto();
//        inputDto.setDoctorId(1L);
//        Patient patient = new Patient();
//        Doctor doctor = new Doctor();
//        Patient savedPatient = new Patient();
//        PatientDto patientDto = new PatientDto();
//
//        when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
//        when(patientRepository.save(any(Patient.class))).thenReturn(savedPatient);
//        when(modelMapper.map(savedPatient, PatientDto.class)).thenReturn(patientDto);
//
//        PatientDto result = patientService.create(inputDto);
//
//        assertNotNull(result);
//        verify(patientRepository).save(any(Patient.class));
//    }
@Test
void testCreatePatientWithDoctor() {
    PatientInputDto inputDto = new PatientInputDto();
    inputDto.setDoctorId(1L);
    inputDto.setFirstName("John");
    inputDto.setLastName("Doe");

    Patient patient = new Patient();
    Doctor doctor = new Doctor();
    Patient savedPatient = new Patient();
    PatientDto patientDto = new PatientDto();

    when(modelMapper.map(inputDto, Patient.class)).thenReturn(patient);
    when(doctorRepository.findById(1L)).thenReturn(Optional.of(doctor));
    when(patientRepository.countPatientsByDoctorIdExcluding(1L, null)).thenReturn(0L);
    when(patientRepository.save(patient)).thenReturn(savedPatient);
    when(modelMapper.map(savedPatient, PatientDto.class)).thenReturn(patientDto);

    PatientDto result = patientService.create(inputDto);

    assertNotNull(result);
    verify(patientRepository).save(patient);
}


    @Test
    void testGetAllPatients() {
        Patient patient = new Patient();
        PatientDto patientDto = new PatientDto();

        when(patientRepository.findAll()).thenReturn(List.of(patient));
        when(modelMapper.map(patient, PatientDto.class)).thenReturn(patientDto);

        List<PatientDto> result = patientService.getAll();

        assertEquals(1, result.size());
    }
//
//    @Test
//    void testUpdatePatient() {
//        Long id = 1L;
//        PatientInputDto inputDto = new PatientInputDto();
//        inputDto.setDoctorId(2L);
//        Patient existing = new Patient();
//        Doctor doctor = new Doctor();
//        Patient updated = new Patient();
//        PatientDto patientDto = new PatientDto();
//
//        when(patientRepository.findById(id)).thenReturn(Optional.of(existing));
//        when(doctorRepository.findById(2L)).thenReturn(Optional.of(doctor));
//        when(patientRepository.save(existing)).thenReturn(updated);
//        when(modelMapper.map(updated, PatientDto.class)).thenReturn(patientDto);
//
//        PatientDto result = patientService.update(id, inputDto);
//
//        assertNotNull(result);
//    }
@Test
void testUpdatePatient() {
    Long id = 1L;
    PatientInputDto inputDto = new PatientInputDto();
    inputDto.setGender("M"); // ✅ FIX
    inputDto.setDoctorId(2L);
    inputDto.setFirstName("Jane");
    inputDto.setLastName("Smith");

    Patient existing = new Patient();
    Doctor doctor = new Doctor();
    Patient updated = new Patient();
    PatientDto patientDto = new PatientDto();

    when(patientRepository.findById(id)).thenReturn(Optional.of(existing));
    when(doctorRepository.findById(2L)).thenReturn(Optional.of(doctor));
    when(patientRepository.countPatientsByDoctorIdExcluding(2L, id)).thenReturn(0L);
    when(patientRepository.save(existing)).thenReturn(updated);
    when(modelMapper.map(updated, PatientDto.class)).thenReturn(patientDto);

    PatientDto result = patientService.update(id, inputDto);

    assertNotNull(result);
}

    @Test
    void testDeletePatient() {
        Long id = 1L;
        when(patientRepository.existsById(id)).thenReturn(true);

        patientService.delete(id);

        verify(patientRepository).deleteById(id);
    }

    @Test
    void testGetPatientById() {
        Long id = 1L;
        Patient patient = new Patient();
        PatientDto patientDto = new PatientDto();

        when(patientRepository.findById(id)).thenReturn(Optional.of(patient));
        when(modelMapper.map(patient, PatientDto.class)).thenReturn(patientDto);

        PatientDto result = patientService.getById(id);

        assertNotNull(result);
    }

    @Test
    void testAssignDoctor() {
        Long patientId = 1L;
        Long doctorId = 2L;
        Patient patient = new Patient();
        Doctor doctor = new Doctor();
        Patient updated = new Patient();
        PatientDto patientDto = new PatientDto();

        when(patientRepository.findById(patientId)).thenReturn(Optional.of(patient));
        when(doctorRepository.findById(doctorId)).thenReturn(Optional.of(doctor));
        when(patientRepository.countPatientsByDoctorIdExcluding(doctorId, patientId)).thenReturn(0L);
        when(patientRepository.save(patient)).thenReturn(updated);
        when(modelMapper.map(updated, PatientDto.class)).thenReturn(patientDto);

        PatientDto result = patientService.assignDoctor(patientId, doctorId);

        assertNotNull(result);
    }

    @Test
    void testRemoveDoctor() {
        Long patientId = 1L;
        Patient patient = new Patient();
        Patient updated = new Patient();
        PatientDto patientDto = new PatientDto();

        when(patientRepository.findById(patientId)).thenReturn(Optional.of(patient));
        when(patientRepository.save(patient)).thenReturn(updated);
        when(modelMapper.map(updated, PatientDto.class)).thenReturn(patientDto);

        PatientDto result = patientService.removeDoctor(patientId);

        assertNotNull(result);
    }
}

