//package com.careflow.cms.integration;
//
//import com.careflow.cms.dto.AppointmentInputDto;
//import com.careflow.cms.model.AppointmentStatus;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.MediaType;
//import org.springframework.test.web.servlet.MockMvc;
//
//import java.time.LocalDate;
//
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
//
//@SpringBootTest
//@AutoConfigureMockMvc
//class AppointmentControllerIntegrationTest {
//
//    @Autowired
//    private MockMvc mockMvc;
//
//    @Autowired
//    private ObjectMapper objectMapper;
//
//    @Test
//    void testCreateAppointment() throws Exception {
//        AppointmentInputDto inputDto = new AppointmentInputDto();
//        inputDto.setDoctorId(3L); // Ensure doctor with ID 1 exists
//        inputDto.setPatientId(2L); // Ensure patient with ID 2 exists
//        inputDto.setAppointmentDate(LocalDate.now());
//        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);
//
//        mockMvc.perform(post("/api/cms/v1/appointments")
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .content(objectMapper.writeValueAsString(inputDto)))
//                .andExpect(status().isCreated())
//                .andExpect(jsonPath("$.appointmentId").exists());
//    }
//
//
//    @Test
//    void testGetAllAppointments() throws Exception {
//        mockMvc.perform(get("/api/cms/v1/appointments"))
//                .andExpect(status().isOk())
//                .andExpect(content().contentType(MediaType.APPLICATION_JSON));
//    }
//
//    @Test
//    void testGetAppointmentById() throws Exception {
//        Long appointmentId = 1L; // Ensure this ID exists in test DB
//
//        mockMvc.perform(get("/api/cms/v1/appointments/" + appointmentId))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
//    }
//
//    @Test
//    void testUpdateAppointment() throws Exception {
//        Long appointmentId = 1L; // Ensure this ID exists
//         AppointmentInputDto inputDto = new AppointmentInputDto();
//        inputDto.setDoctorId(1L);
//        inputDto.setPatientId(2L);
//        inputDto.setAppointmentDate(LocalDate.now().plusDays(1));
//        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);
//
//        mockMvc.perform(put("/api/cms/v1/appointments/" + appointmentId)
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(objectMapper.writeValueAsString(inputDto)))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
//    }
//
//    @Test
//    void testDeleteAppointment() throws Exception {
//        Long appointmentId = 1L; // Ensure this ID exists
//
//        mockMvc.perform(delete("/api/cms/v1/appointments/" + appointmentId))
//                .andExpect(status().isNoContent());
//    }
//
//    @Test
//    void testGetAppointmentsForToday() throws Exception {
//        mockMvc.perform(get("/api/cms/v1/appointments/today"))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void testGetAppointmentsByDoctor() throws Exception {
//        Long doctorId = 1L;
//
//        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void testGetAppointmentsByDateAndStatus() throws Exception {
//        LocalDate date = LocalDate.now();
//        AppointmentStatus status = AppointmentStatus.SCHEDULED;
//
//        mockMvc.perform(get("/api/cms/v1/appointments/date/")
//                .param("date", date.toString())
//                .param("status", status.name()))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void testGetAppointmentsByDoctorAndDate() throws Exception {
//        Long doctorId = 1L;
//        LocalDate date = LocalDate.now();
//
//        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId + "/date")
//                .param("date", date.toString()))
//                .andExpect(status().isOk());
//    }
//
//    @Test
//    void testGetPatientsByAppointmentDateAndStatus() throws Exception {
//        LocalDate date = LocalDate.now();
//        AppointmentStatus status = AppointmentStatus.SCHEDULED;
//
//        mockMvc.perform(get("/api/cms/v1/appointments/patients")
//                .param("date", date.toString())
//                .param("status", status.name()))
//                .andExpect(status().isOk());
//    }
//}

package com.careflow.cms.integration;

import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.model.AppointmentStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AppointmentControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private final Long doctorId = 3L;     // Make sure this doctor exists
    private final Long patientId = 2L;    // Make sure this patient exists
    private final Long appointmentId = 1L; // Make sure this appointment exists

    @Test
    void testCreateAppointment() throws Exception {
        AppointmentInputDto inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(doctorId);
        inputDto.setPatientId(patientId);
        inputDto.setAppointmentDate(LocalDate.now());
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        mockMvc.perform(post("/api/cms/v1/appointments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.appointmentId").exists());
    }

    @Test
    void testGetAllAppointments() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));
    }

    @Test
    void testGetAppointmentById() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/" + appointmentId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
    }

    @Test
    void testUpdateAppointment() throws Exception {
        AppointmentInputDto inputDto = new AppointmentInputDto();
        inputDto.setDoctorId(doctorId);
        inputDto.setPatientId(patientId);
        inputDto.setAppointmentDate(LocalDate.now().plusDays(1));
        inputDto.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        mockMvc.perform(put("/api/cms/v1/appointments/" + appointmentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(inputDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.appointmentId").value(appointmentId));
    }

    @Test
    void testDeleteAppointment() throws Exception {
        mockMvc.perform(delete("/api/cms/v1/appointments/" + appointmentId))
                .andExpect(status().isNoContent());
    }

    @Test
    void testGetAppointmentsForToday() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/today"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDoctor() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDateAndStatus() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/date/")
                        .param("date", LocalDate.now().toString())
                        .param("status", AppointmentStatus.SCHEDULED.name()))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAppointmentsByDoctorAndDate() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/doctor/" + doctorId + "/date")
                        .param("date", LocalDate.now().toString()))
                .andExpect(status().isOk());
    }

    @Test
    void testGetPatientsByAppointmentDateAndStatus() throws Exception {
        mockMvc.perform(get("/api/cms/v1/appointments/patients")
                        .param("date", LocalDate.now().toString())
                        .param("status", AppointmentStatus.SCHEDULED.name()))
                .andExpect(status().isOk());
    }
}
