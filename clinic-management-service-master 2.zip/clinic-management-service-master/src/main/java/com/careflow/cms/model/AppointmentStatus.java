package com.careflow.cms.model;

public enum AppointmentStatus {
    SCHEDULED, COMPLETED, CANCELLED
}
