package com.careflow.cms.controller;

import com.careflow.cms.dto.PatientDto;
import com.careflow.cms.dto.PatientInputDto;
import com.careflow.cms.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cms/v1/patients")
@Tag(name = "Patients API", description = "Patients API for CRUD Operation")
public class PatientController {
    private static final Logger log = LoggerFactory.getLogger(PatientController.class);

    @Autowired
    private PatientService patientService;

    @PostMapping
    @Operation(summary = "Create a New Patient")
    public ResponseEntity<PatientDto> create(@Valid @RequestBody PatientInputDto patientInputDto) {
        log.info("Received request: POST /api/patients with data: {}", patientInputDto);
        PatientDto created = patientService.create(patientInputDto);
        log.info("Created patient with id {}", created.getPatientId());
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Display a List of Patients")
    public ResponseEntity<List<PatientDto>> getAll() {
        log.info("Received request: GET /api/patients");
        List<PatientDto> patientDtos = patientService.getAll();
        log.info("Returning {} patients", patientDtos.size());
        return ResponseEntity.ok(patientDtos);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an Existing Patient")
    public ResponseEntity<PatientDto> update(@PathVariable Long id, @Valid @RequestBody PatientInputDto patientInputDto) {
        log.info("Received request: PUT /api/patients/{} with data: {}", id, patientInputDto);
        PatientDto updated = patientService.update(id, patientInputDto);
        log.info("Updated patient with id {}", id);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an Existing Patient")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        log.info("Received request: DELETE /api/patients/{}", id);
        patientService.delete(id);
        log.info("Deleted patient with id {}", id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Find an Existing Patient")
    public ResponseEntity<PatientDto> getById(@PathVariable Long id) {
        log.info("Received request: GET /api/patients/{}", id);
        PatientDto patientDto = patientService.getById(id);
        log.info("Returning patient with id {}", id);
        return ResponseEntity.ok(patientDto);
    }

    @PutMapping("/{patientId}/assign-doctor/{doctorId}")
    @Operation(summary = "Assign a Doctor to an Existing Patient")
    public ResponseEntity<PatientDto> assignDoctor(@PathVariable Long patientId,@PathVariable Long doctorId) {
        log.info("Received request: PUT /api/patients/{patientId}/assign-doctor/{doctorId}", patientId, doctorId);
        PatientDto patientDto = patientService.assignDoctor(patientId, doctorId);
        log.info("Assign doctor with id {}", doctorId);
        return ResponseEntity.ok(patientDto);
    }

    @PutMapping("/{patientId}/remove-doctor")
    @Operation(summary = "Remove a Doctor from an Existing Patient")
    public ResponseEntity<PatientDto> removeDoctor(@PathVariable Long patientId) {
        log.info("Received request: PUT /api/patients/{patientId}/remove-doctor", patientId);
        PatientDto patientDto = patientService.removeDoctor(patientId);
        log.info("Remove doctor from patient with id {}", patientId);
        return ResponseEntity.ok(patientDto);
    }
}
