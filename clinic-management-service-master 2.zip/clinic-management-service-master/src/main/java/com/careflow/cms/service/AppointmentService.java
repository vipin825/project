package com.careflow.cms.service;

import com.careflow.cms.dto.AppointmentDto;
import com.careflow.cms.dto.AppointmentInputDto;
import com.careflow.cms.dto.DoctorSummaryDto;
import com.careflow.cms.dto.PatientSummaryDto;
import com.careflow.cms.exception.ConflictException;
import com.careflow.cms.exception.DoctorCapacityExceededException;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.Appointment;
import com.careflow.cms.model.AppointmentStatus;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import com.careflow.cms.repository.AppointmentRepository;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.repository.PatientRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppointmentService {

    private static final Logger log = LoggerFactory.getLogger(AppointmentService.class);
    private static final int MAX_PATIENTS_PER_DOCTOR = 4;

    @Autowired
    private AppointmentRepository appointmentRepository;
    @Autowired
    private DoctorRepository doctorRepository;
    @Autowired
    private PatientRepository patientRepository;
    @Autowired
    private ModelMapper mapper;

    @Transactional
    public AppointmentDto create(AppointmentInputDto appointmentInputDto) {
        log.info("Creating Appointment for Patient Id {} with Doctor {} on {}", appointmentInputDto.getPatientId(),
                appointmentInputDto.getDoctorId(), appointmentInputDto.getAppointmentDate());
        //mapper.getConfiguration().setAmbiguityIgnored(true);
        Appointment appointment = mapper.map(appointmentInputDto, Appointment.class);
        appointment.setAppointmentId(null); // Force to null to avoid update

        Patient patient = patientRepository.findById(appointmentInputDto.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + appointmentInputDto.getPatientId()));

        Doctor doctor = doctorRepository.findById(appointmentInputDto.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + appointmentInputDto.getDoctorId()));

        validateDuplicateAppoinments(appointmentInputDto, patient);

        if (patient.getDoctor() == null) {
            long patientCount = patientRepository.countPatientsByDoctorIdExcluding(appointmentInputDto.getDoctorId(), null);

            if (patientCount >= MAX_PATIENTS_PER_DOCTOR) {
                throw new DoctorCapacityExceededException("Doctor with Id " + appointmentInputDto.getDoctorId() + " already has the maximum allowed number of patients.");
            }
            patient.setDoctor(doctor);
            patientRepository.save(patient);
        } else if (!patient.getDoctor().getDoctorId().equals(doctor.getDoctorId())) {
            throw new ConflictException("Patient Id " + appointmentInputDto.getPatientId() + " is assigned to a different doctor.Please update Patient's Doctor first");
        }

        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(appointmentInputDto.getAppointmentDate());
        appointment.setAppointmentStatus(AppointmentStatus.SCHEDULED);

        try {
            Appointment saved = appointmentRepository.save(appointment);
            return mapToDto(saved);
        } catch (DataIntegrityViolationException e) {
            throw new ConflictException("Appointment conflict : " + e.getMessage());
        }
    }

    public List<AppointmentDto> getAll() {
        log.info("Get All Appointments");
        List<Appointment> appointments = appointmentRepository.findAll();

        return appointments.stream()
                .map(this::mapToDto).toList();
    }

    @Transactional
    public AppointmentDto update(Long id, AppointmentInputDto appointmentInputDto) {
        log.info("Update Appointment #{}", id);

        Appointment existing = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Appointment with id : " + id));

        Doctor doctor = doctorRepository.findById(appointmentInputDto.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + appointmentInputDto.getDoctorId()));

        Patient patient = patientRepository.findById(appointmentInputDto.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + appointmentInputDto.getPatientId()));

        validateDuplicateAppoinments(appointmentInputDto, patient);
        if (patient.getDoctor() == null) {
            long patientCount = patientRepository.countPatientsByDoctorIdExcluding(appointmentInputDto.getDoctorId(), appointmentInputDto.getPatientId());

            if (patientCount >= MAX_PATIENTS_PER_DOCTOR) {
                throw new DoctorCapacityExceededException("Doctor with Id " + appointmentInputDto.getDoctorId() + " already has the maximum allowed number of patients.");
            }
            patient.setDoctor(doctor);
            patientRepository.save(patient);
        } else if (!patient.getDoctor().getDoctorId().equals(doctor.getDoctorId())) {
            throw new ConflictException("Patient Id " + appointmentInputDto.getPatientId() + " is assigned to a different doctor.Please update Patient's Doctor first");
        }
        existing.setPatient(patient);
        existing.setDoctor(doctor);
        existing.setAppointmentDate(appointmentInputDto.getAppointmentDate());
        existing.setAppointmentStatus(appointmentInputDto.getAppointmentStatus());

        return mapToDto(appointmentRepository.save(existing));
    }

    @Transactional
    public void delete(Long id) {
        log.info("Deleting an Appointment with Id {}", id);
        if (!appointmentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot find Appointment with id : " + id);
        }
        appointmentRepository.deleteById(id);
    }

    public AppointmentDto getById(Long id) {
        log.info("Get an Appointment by Id {}", id);
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));
        return mapToDto(appointment);
    }

    public List<AppointmentDto> getAppointmentsForToday() {
        log.info("Get all Appointments for Today");
        LocalDate today = LocalDate.now();
        List<Appointment> appointments = appointmentRepository.findByAppointmentDate(today);
        return appointments.stream()
                .map(a -> mapper.map(a, AppointmentDto.class))
                .collect(Collectors.toList());
    }

    public List<AppointmentDto> getAppointmentsByDoctor(Long doctorId) {
        log.info("Get Appointments for Doctor {}", doctorId);
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + doctorId));

        List<Appointment> appointments = appointmentRepository.findByDoctor(doctor);
        return appointments.stream()
                .map(a -> mapper.map(a, AppointmentDto.class))
                .collect(Collectors.toList());
    }

    public List<AppointmentDto> getAppointmentsByDateAndStatus(LocalDate date, AppointmentStatus status) {
        log.info("Get Appointments for date {} and status {}", date, status);
        List<Appointment> appointments = appointmentRepository.findByAppointmentDateAndAppointmentStatus(date, status);
        return appointments.stream()
                .map(a -> mapper.map(a, AppointmentDto.class))
                .collect(Collectors.toList());
    }

    public List<AppointmentDto> getAppointmentsByDoctorAndDate(Long doctorId, LocalDate date) {
        log.info("Get Appointments for doctor {} on date {}", doctorId, date);
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + doctorId));

        List<Appointment> appointments = appointmentRepository.findByDoctorAndAppointmentDate(doctor, date);
        return appointments.stream()
                .map(a -> mapper.map(a, AppointmentDto.class))
                .collect(Collectors.toList());
    }

    public List<PatientSummaryDto> getPatientsByAppointmentDateAndStatus(LocalDate date, AppointmentStatus status) {
        log.info("Get Patients with Appointments on Date {} and Status {}", date, status);

        List<Appointment> appointments = appointmentRepository.findByAppointmentDateAndAppointmentStatus(date, status);

        return appointments.stream()
                .map(Appointment::getPatient)
                .map(patient -> mapper.map(patient, PatientSummaryDto.class))
                .collect(Collectors.toList());
    }

    private AppointmentDto mapToDto(Appointment appointment) {
        AppointmentDto appointmentDto = mapper.map(appointment, AppointmentDto.class);
        DoctorSummaryDto doctorSummaryDto = mapper.map(appointment.getDoctor(), DoctorSummaryDto.class);
        PatientSummaryDto patientSummaryDto = mapper.map(appointment.getPatient(), PatientSummaryDto.class);

        appointmentDto.setDoctor(doctorSummaryDto);
        appointmentDto.setPatient(patientSummaryDto);

        return appointmentDto;
    }

    private void validateDuplicateAppoinments(AppointmentInputDto appointmentInputDto, Patient patient) {
        if (appointmentRepository.findByPatientAndAppointmentDateAndAppointmentStatus(patient, appointmentInputDto.getAppointmentDate(), appointmentInputDto.getAppointmentStatus()).isPresent()) {
            throw new ConflictException("Patient with Id " + appointmentInputDto.getPatientId() + " already has " + appointmentInputDto.getAppointmentStatus() + " an appointment on "
                    + appointmentInputDto.getAppointmentDate());
        }
    }

}
