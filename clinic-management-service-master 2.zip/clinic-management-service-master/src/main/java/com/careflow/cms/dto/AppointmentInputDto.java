package com.careflow.cms.dto;

import com.careflow.cms.model.AppointmentStatus;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentInputDto {
    @NotNull(message = "Patient Id is required")
    private Long patientId;

    @NotNull(message = "Doctor Id is required")
    private Long doctorId;

    @NotNull(message = "Appointment Date is required")
    @FutureOrPresent(message = "Appointment Date must be today or in the future")
    private LocalDate appointmentDate;

    @NotNull(message = "Appointment Status is required")
    private AppointmentStatus appointmentStatus; // e.g., SCHEDULED, COMPLETED, CANCELLED

}
