package com.careflow.cms.repository;

import com.careflow.cms.model.Appointment;
import com.careflow.cms.model.AppointmentStatus;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment,Long> {

    Optional<Appointment> findByPatientAndAppointmentDateAndAppointmentStatus(Patient patient, LocalDate appointmentDate, AppointmentStatus appointmentStatus);

    // All appointments for today
    List<Appointment> findByAppointmentDate(LocalDate date);

    // All appointments for a specific doctor
    List<Appointment> findByDoctor(Doctor doctor);

    // All appointments for a specific date and status
    List<Appointment> findByAppointmentDateAndAppointmentStatus(LocalDate date, AppointmentStatus status);

    // All appointments for a doctor on a specific date
    List<Appointment> findByDoctorAndAppointmentDate(Doctor doctor, LocalDate date);


}
