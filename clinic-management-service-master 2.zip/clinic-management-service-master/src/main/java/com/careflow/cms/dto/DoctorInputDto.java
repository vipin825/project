package com.careflow.cms.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DoctorInputDto {

    @NotBlank(message = "First Name is required")
    @Size(max = 50, message = "First Name cannot have more than 50 characters")
    private String firstName;

    @NotBlank(message = "Last Name is required")
    @Size(max = 50, message = "Last Name cannot have more than 50 characters")
    private String lastName;

    @Size(max = 255, message = "Specialty cannot have more than 255 characters")
    private String specialty;

    @Pattern(regexp = "^[1-9]{10,18}$", message = "Invalid Phone Number")
    @Size(max = 20, message = "Phone Number cannot have more than 20 characters")
    private String phoneNumber;

    @Email(message = "Email should be valid")
    @Size(max = 100, message = "Email cannot have more than 100 characters")
    private String email;

}
