package com.careflow.cms.dto;

import com.careflow.cms.model.AppointmentStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppointmentDto {
    private Long appointmentId;

    private PatientSummaryDto patient;

    private DoctorSummaryDto doctor;

    private LocalDate appointmentDate;

    private AppointmentStatus appointmentStatus; // e.g., SCHEDULED, COMPLETED, CANCELLED

}
