package com.careflow.cms.service;

import com.careflow.cms.dto.PatientDto;
import com.careflow.cms.exception.DoctorCapacityExceededException;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.model.Patient;
import com.careflow.cms.repository.DoctorRepository;
import com.careflow.cms.repository.PatientRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private ModelMapper mapper;

    @Transactional
    public PatientDto create(PatientDto patientDto){
        Patient patient = mapper.map(patientDto, Patient.class);

        if(patientDto.getDoctorId() != null){
            Doctor doctor = getDoctorWithCapacityCheck(patientDto.getDoctorId());
            patient.setDoctor(doctor);
        }

        Patient saved = patientRepository.save(patient);

        return mapper.map(saved, PatientDto.class);
    }



    public List<PatientDto> getAll(){
        List<Patient> patients = patientRepository.findAll();
        return patients.stream()
                .map(patient -> mapper.map(patient, PatientDto.class))
                .collect(Collectors.toList());
    }

    @Transactional
    public PatientDto update(Long id, PatientDto patientDto){
        Patient existing = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));

        existing.setFirstName(patientDto.getFirstName());
        existing.setLastName(patientDto.getLastName());
        existing.setDateOfBirth(patientDto.getDateOfBirth());
        existing.setGender(patientDto.getGender());
        existing.setPhoneNumber(patientDto.getPhoneNumber());
        existing.setEmail(patientDto.getEmail());

        if(patientDto.getDoctorId() != null){
            Doctor doctor = getDoctorWithCapacityCheck(patientDto.getDoctorId(),patientDto.getPatientId());
            existing.setDoctor(doctor);
        }else{
            existing.setDoctor(null);
        }
        return mapper.map(patientRepository.save(existing), PatientDto.class);
    }

    @Transactional
    public void delete(Long id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));
        patientRepository.delete(patient);
    }

    public PatientDto getById(Long id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + id));
        return mapper.map(patient, PatientDto.class);
    }

    private Doctor getDoctorWithCapacityCheck(Long doctorId, Long excluedPatientId){
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + doctorId));

        long patientCount = patientRepository.countPatientsByDoctorIdExcluding(doctorId, excluedPatientId);

        if(patientCount >= 4){
            throw new DoctorCapacityExceededException("Doctor with Id " + doctorId + " already has the maximum allowed number of patients.");
        }

        return doctor;
    }

    private Doctor getDoctorWithCapacityCheck(Long doctorId) {
        return getDoctorWithCapacityCheck(doctorId,null);
    }

    public PatientDto assignDoctor(Long patientId, Long doctorId){
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + patientId));

        Doctor doctor = getDoctorWithCapacityCheck(doctorId,patientId);
        patient.setDoctor(doctor);

        return mapper.map(patientRepository.save(patient),PatientDto.class);
    }

    public PatientDto removeDoctor(Long patientId){
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Patient with id : " + patientId));

        patient.setDoctor(null);

        return mapper.map(patientRepository.save(patient),PatientDto.class);
    }


}
