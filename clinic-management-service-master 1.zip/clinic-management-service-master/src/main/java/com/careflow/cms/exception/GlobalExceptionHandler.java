package com.careflow.cms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(code = HttpStatus.NOT_FOUND)
    public ProblemDetail handleResourceNotFoundException(ResourceNotFoundException ex) {
        ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
        problemDetail.setTitle("Resource Not Found");
        problemDetail.setProperty("reason",ex.getMessage());
        problemDetail.setProperty("severity","ERROR");
        return problemDetail;
    }

    @ExceptionHandler(DoctorCapacityExceededException.class)
    @ResponseStatus(code = HttpStatus.CONFLICT)
    public ProblemDetail handleDoctorCapacityExceededException(DoctorCapacityExceededException ex) {
        ProblemDetail problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, ex.getMessage());
        problemDetail.setTitle("Doctor Capacity Exceeded");
        problemDetail.setProperty("reason",ex.getMessage());
        problemDetail.setProperty("severity","ERROR");
        return problemDetail;
    }
}
