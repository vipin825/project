package com.careflow.cms.controller;

import com.careflow.cms.dto.PatientDto;
import com.careflow.cms.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cms/v1/patients")
@Tag(name = "Patient API", description = "Patient API for CRUD Operation")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @PostMapping
    @Operation(summary = "Create a New Patient")
    public ResponseEntity<PatientDto> create(@RequestBody PatientDto patientDto) {
        return new ResponseEntity<>(patientService.create(patientDto), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Display a List of Patients")
    public ResponseEntity<List<PatientDto>> getAll() {
        return ResponseEntity.ok(patientService.getAll());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an Existing Patient")
    public ResponseEntity<PatientDto> update(@PathVariable Long id, @RequestBody PatientDto patientDto) {
        return ResponseEntity.ok(patientService.update(id, patientDto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete an Existing Patient")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        patientService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Find an Existing Patient")
    public ResponseEntity<PatientDto> getById(@PathVariable Long id) {
        return ResponseEntity.ok(patientService.getById(id)) ;
    }

    @PutMapping("/{patientId}/assign-doctor/{doctorId}")
    @Operation(summary = "Assign a Doctor to an Existing Patient")
    public ResponseEntity<PatientDto> assignDoctor(@PathVariable Long patientId,@PathVariable Long doctorId) {
        return ResponseEntity.ok(patientService.assignDoctor(patientId, doctorId));
    }

    @PutMapping("/{patientId}/remove-doctor")
    @Operation(summary = "Remove a Doctor from an Existing Patient")
    public ResponseEntity<PatientDto> removeDoctor(@PathVariable Long patientId) {
        return ResponseEntity.ok(patientService.removeDoctor(patientId));
    }
}
