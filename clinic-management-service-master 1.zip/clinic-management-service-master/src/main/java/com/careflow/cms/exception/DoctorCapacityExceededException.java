package com.careflow.cms.exception;

public class DoctorCapacityExceededException extends RuntimeException {
    public DoctorCapacityExceededException(String message) {
        super(message);
    }
}
