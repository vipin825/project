package com.careflow.cms.service;

import com.careflow.cms.dto.DoctorDto;
import com.careflow.cms.exception.ResourceNotFoundException;
import com.careflow.cms.model.Doctor;
import com.careflow.cms.repository.DoctorRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private ModelMapper mapper;

    @Transactional
    public DoctorDto create(DoctorDto doctorDto){
        Doctor doctor = mapper.map(doctorDto,Doctor.class);
        Doctor saved = doctorRepository.save(doctor);

        return mapper.map(saved, DoctorDto.class );
    }

    public List<DoctorDto> getAll(){
        List<Doctor> doctors = doctorRepository.findAll();
        return doctors.stream()
                .map(doctor -> mapper.map(doctor, DoctorDto.class))
                .collect(Collectors.toList());
    }

    @Transactional
    public DoctorDto update(Long id, DoctorDto doctorDto){
        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + id));

        existing.setFirstName(doctorDto.getFirstName());
        existing.setLastName(doctorDto.getLastName());
        existing.setSpecialty(doctorDto.getSpecialty());
        existing.setPhoneNumber(doctorDto.getPhoneNumber());
        existing.setEmail(doctorDto.getEmail());

        return mapper.map(doctorRepository.save(existing), DoctorDto.class);
    }

    @Transactional
    public void delete(Long id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + id));
        doctorRepository.delete(doctor);
    }

    public DoctorDto getById(Long id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cannot find Doctor with id : " + id));
        return mapper.map(doctor, DoctorDto.class);
    }
}
